----------------- DROP -----------------
DROP PROCEDURE INSERT_POST;
DROP VIEW REV_POSTS;
DROP VIEW POST_DISCUSSION;

DROP TABLE autor_hat_artikel;
DROP TABLE autor_hat_sprache;
DROP TABLE revision;
DROP TABLE mitarbeiter;
DROP TABLE post;
DROP TABLE autor;
DROP TABLE sprache;
DROP TABLE universitaet;
DROP TABLE person;