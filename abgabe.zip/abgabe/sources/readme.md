Der Code ist auch auf GitHub:\
https://github.com/christophbuehler/dbs

**Java Code:**\
`./dummy-data`

**PHP API Code:**\
`./`

**Frontend Code:**\
`dbs-frontend\src\app`

