<?php
$sign = $_SERVER['HTTP_X_HUB_SIGNATURE'];
$secret = '#2j([ttZ!da8MrloPs30x';
$post_data = file_get_contents('php://input');
$signature = hash_hmac('sha1', $post_data, $secret);
$allowed = $sign == 'sha1=' . $signature;

if (!$allowed) {
	header('HTTP/1.1 403 Forbidden');
	echo 'Not allowed.';
	exit;
}

$tmp = shell_exec("/usr/bin/git pull>&1");
echo htmlentities(trim($tmp));

echo "Done.";
?>